


print("======================================================")
print("         UNIVERSIDAD DE LAS FUERZAS ARMADAS ESPE     ")
print("           APLICACIÓN DE SISTEMAS WEB          ")
print("======================================================")
print("******************* MENU DE OPCIONES ****************")
print("Ejercio [1]  ->  Ingresar el radio de un círculo del usuario y calcule el área.")
print("Ejercio [2]  ->  Calcular el teorema de Pitágoras.")
print("Ejercio [3]  ->  Ingresar la longitud y el ancho de un rectángulo y encontrar su perímetro.")
print("Ejercio [4]  ->  Probar si es un numero negativo.")
print("Ejercio [5]  ->  Ingresar calificaciones de cinco materias y calcular el total, el promedio y el porcentaje.")
print("Ejercio [6]  ->  Preguntar al usuario su nombre y lo salude con su nombre..")
numeroMunu=int(input("Seleccione la opcion que desea \n"))

if(numeroMunu==1):
    print("           ****************   E J E R C I C I O  #1    *****************        ")
    print("        Ingresar el radio de un círculo del usuario y calcule el área")
    radioCirculo=int(input("Ingrese el radio del circulo \n"))
    print("Radio Ingresado ->","[",radioCirculo,"]")
    areaCirculo=3.1416*radioCirculo*radioCirculo
    print("Area del Circulo ->", "[",areaCirculo,"]")
  
elif(numeroMunu==2):
    print("           ****************   E J E R C I C I O  #2    *****************        ")
    print("                      Calcular el teorema de Pitágoras.                         ")
    print("++++++++  Encontrar la Hipotenusa  +++++++")
    catetoA=int(input("Ingrese un numero para el cateto A:  "))
    catetoB=int(input("Ingrese un numero para el cateto B:  "))
    hipotenusa= (catetoA*catetoA+catetoB*catetoB)**0.5
    print("Hipòtenusa -> ", "",hipotenusa)
    print("++++++++  Encontrar el cateto B +++++++")
    catetoA=int(input("Ingrese un numero para el cateto A:  "))
    hipotenusa=int(input("Ingrese un numero para la Hipotenusa:  "))
    catetoB=(hipotenusa*hipotenusa-catetoA*catetoA)**0.5
    print("El cateto B -> ","",catetoB)
    print("++++++++  Encontrar el cateto A +++++++")
    catetoB=int(input("Ingrese un numero para el cateto B:  "))
    hipotenusa=int(input("Ingrese un numero para la Hipotenusa:  "))
    catetoA=(hipotenusa*hipotenusa-catetoB*catetoB)**0.5
    print("El cateto A ->","",catetoA)


     
elif(numeroMunu==3):
     print("           ****************   E J E R C I C I O  #3    *****************        ")
     print("     Ingresar la longitud y el ancho de un rectángulo y encontrar su perímetro.")
     longitudRectangulo=int(input("Ingrese la longitud del rectangulo \n  "))
     anchoRectangulo=int(input("Ingrese el ancho del rectangulo \n"))
     perimetroRectangulo=2*longitudRectangulo+2*anchoRectangulo
     print("Longitud del Rectangulo ->","[",longitudRectangulo,"]")
     print("Ancho del Rectangulo ->","[",anchoRectangulo,"]")
     print("Perimetro del Rectangulo  : ","",perimetroRectangulo)

elif(numeroMunu==4):
    print("           ****************   E J E R C I C I O  #4    *****************        ")
    print("                        Probar si es un numero negativo    ")
    comprobarNumero= float(input("Ingrese un número  \n"))
    if(comprobarNumero<0):
        print("El numero que ingreso es negativo",comprobarNumero)
    elif(comprobarNumero>0):
        print("El numero que ingreso es positivo",comprobarNumero)


elif(numeroMunu==5):
     print("           ****************   E J E R C I C I O  #5   *****************        ")
     print("      Ingresar calificaciones de cinco materias y calcular el total, el promedio y el porcentaje     ")
     notaEstadistica=float(input("Ingresar la nota de Estadistica:  "))
     nota_Sistemas_Operativos=float(input("Ingresar la nota de Sistema Operativo:  "))
     nota_EDO=float(input("Ingresar la nota de Ecuaciones Diferenciales Ordinarias: "))
     nota_Interfaces=float(input("Ingrese la nota de Interfaces:  "))
     notaBaseDatos=float(input("Ingrese la nota de Base de Datos:  "))
     print("**********************  C A L I F I C A C I O N E S   ***********************")
     print("Nota Estadistica ->",notaEstadistica)
     print("Nota de Sistemas Operativo ->",nota_Sistemas_Operativos)
     print("Nota de Ecuaciones Diferenciales -> ",nota_EDO)
     print("Nota de Interfaces ->",nota_Interfaces)
     print("Nota de Bases de Datos ->",notaBaseDatos)
     totalCalificaciones=notaEstadistica+nota_Sistemas_Operativos+nota_EDO+nota_Interfaces+notaBaseDatos
     promedio=  totalCalificaciones/5
     porcentaje=totalCalificaciones/promedio*100
     print("    Total       ->  ",totalCalificaciones)
     print("    Promedio    ->   ",promedio)
     print("    Porcentaje  ->  ",porcentaje)
elif(numeroMunu==6):
      print("           ****************   E J E R C I C I O  #6   *****************        ")
      print("              Preguntar al usuario su nombre y lo salude con su nombre       ")
      nombre=input("Ingrese su nombre  \n")
      print("El nombre que ingreso es -> ", nombre)
      print("Hola","",nombre,"","Bienvenido a mi programa de Python")
else:
    print("El numero que eligio es incorrecto intentelo nuevamente")
    




      
